import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  static const String apiKey = 'YOUR_API_KEY';

  static Future<String> fetchResponse(String prompt) async {
    final url = Uri.parse('https://api-inference.huggingface.co/models/text-model');
    final headers = {'Authorization': 'Bearer $apiKey'};
    final body = jsonEncode({'inputs': prompt});

    final response = await http.post(url, headers: headers, body: body);
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['generated_text'] ?? "No response.";
    }
    return "Error: ${response.reasonPhrase}";
  }

  static Future<String> transcribeAudio(String filePath) async {
    final url = Uri.parse('https://api-inference.huggingface.co/models/audio-model');
    final headers = {'Authorization': 'Bearer $apiKey'};
    final request = http.MultipartRequest('POST', url);
    request.files.add(await http.MultipartFile.fromPath('file', filePath));
    request.headers.addAll(headers);

    final response = await request.send();
    if (response.statusCode == 200) {
      final responseData = await response.stream.bytesToString();
      final data = jsonDecode(responseData);
      return data['text'] ?? "Transkripsi tidak tersedia.";
    }
    return "Gagal mentranskripsi audio.";
  }
}